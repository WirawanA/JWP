<?php
// 1. Memulai atau memanggil kembali session yang sedang berjalan.
// Meskipun kita ingin menghancurkannya, PHP harus tahu dulu "ruang memori" mana yang aktif saat ini.
// Oleh karena itu, session_start() wajib dipanggil di baris paling atas.
session_start();

// 2. Menghancurkan seluruh data session yang tersimpan di server.
// Perintah ini akan menghapus variabel $_SESSION['admin'] yang sebelumnya dibuat saat login.
// Dengan terhapusnya variabel tersebut, kunci akses pengguna ke panel admin resmi dicabut.
session_destroy();

// 3. Mengarahkan (redirect) pengguna secara otomatis kembali ke halaman login utama (index.php).
// Karena kunci aksesnya sudah dihapus, pengguna tidak akan bisa lagi mengakses halaman dashboard dkk.
header("Location: index.php");

// 4. Menghentikan eksekusi skrip secara total.
// Ini adalah praktik keamanan standar (best practice). Tujuannya memastikan bahwa setelah perintah redirect dikeluarkan, 
// tidak ada lagi kode PHP di bawahnya (jika ada) yang tidak sengaja tereksekusi oleh server.
exit;
?>