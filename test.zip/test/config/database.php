<?php
// 1. Menginisialisasi variabel konfigurasi server database MySQL lokal (XAMPP).
$host = "localhost"; // Nama host server database (secara lokal adalah localhost).
$user = "root";      // Username default untuk masuk ke MySQL di XAMPP.
$pass = "";          // Password default MySQL di XAMPP (secara default dikosongkan).

// 2. Menentukan nama basis data yang digunakan oleh aplikasi.
// Sesuai konfigurasi folder 'test', pastikan nama database di phpMyAdmin Anda sudah sesuai.
$db   = "db_kelontong"; 

// 3. Membuka koneksi baru ke server MySQL menggunakan fungsi bawaan PHP yaitu mysqli_connect.
// Fungsi ini menerima 4 parameter utama: host, user, password, dan nama database.
$conn = mysqli_connect($host, $user, $pass, $db);

// 4. Struktur Kondisional (Pengecekan): Memeriksa apakah koneksi database gagal terhubung.
// Simbol tanda seru (!) berarti "Jika tidak berhasil terhubung/logika bernilai FALSE".
if (!$conn) {
    
    // 5. Fungsi die() akan menghentikan seluruh jalannya program web secara paksa 
    // dan menampilkan teks error spesifik dari MySQL menggunakan fungsi mysqli_connect_error().
    die("Koneksi database gagal: " . mysqli_connect_error());
}

// 6. Membuat variabel URL dasar ($base_url) secara semi-otomatis untuk mengunci jalur aset proyek.
// $_SERVER['HTTP_HOST'] berfungsi mengambil alamat domain saat ini (misal: localhost).
// Dengan menggabungkannya dengan folder "/test/", maka isi variabel menjadi "http://localhost/test/".
$base_url = "http://" . $_SERVER['HTTP_HOST'] . "/test/";
?>