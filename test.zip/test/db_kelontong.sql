CREATE DATABASE IF NOT EXISTS `db_kelontong`;
USE `db_kelontong`;

-- 1. Tabel Kategori
CREATE TABLE `categories` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `category_name` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

INSERT INTO `categories` (`id`, `category_name`) VALUES
(1, 'Sembako Base'),
(2, 'Mie & Makanan Instan'),
(3, 'Minuman & Susu'),
(4, 'Sabun & Kebutuhan Mandi');

-- 2. Tabel Produk
CREATE TABLE `products` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `product_code` varchar(20) NOT NULL UNIQUE,
  `product_name` varchar(150) NOT NULL,
  `category_id` int(11) DEFAULT NULL,
  `stock` int(11) DEFAULT 0,
  `unit` varchar(30) NOT NULL,
  PRIMARY KEY (`id`),
  FOREIGN KEY (`category_id`) REFERENCES `categories` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

INSERT INTO `products` (`id`, `product_code`, `product_name`, `category_id`, `stock`, `unit`) VALUES
(1, 'BRG-001', 'Minyak Goreng Bimoli 1L', 1, 15, 'Pouch'),
(2, 'BRG-002', 'Beras Cianjur 5kg', 1, 4, 'Karung'), -- Stok < 10 (Akan memicu alert)
(3, 'BRG-003', 'Indomie Goreng Spesial', 2, 120, 'Bungkus'),
(4, 'BRG-004', 'Susu Kental Manis Frisian Flag', 3, 8, 'Kaleng'); -- Stok < 10 (Akan memicu alert)

-- 3. Tabel Mutasi Stok
CREATE TABLE `stock_mutations` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `product_id` int(11) DEFAULT NULL,
  `type` enum('masuk','keluar') NOT NULL,
  `quantity` int(11) NOT NULL,
  `date` date NOT NULL,
  PRIMARY KEY (`id`),
  FOREIGN KEY (`product_id`) REFERENCES `products` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- 4. Tabel Pengguna/Admin
CREATE TABLE `users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `password` varchar(255) NOT NULL,
  `role` varchar(50) DEFAULT 'Admin Utama',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

INSERT INTO `users` (`id`, `name`, `password`, `role`) VALUES
(1, 'admin', 'admin', 'Admin Utama');