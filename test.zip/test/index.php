<?php
// 1. Memulai session PHP untuk menyimpan data login pengguna di server.
// Ini wajib diletakkan di baris paling atas sebelum ada output HTML.
session_start();

// 2. Menyisipkan file konfigurasi database agar variabel koneksi ($conn) bisa digunakan.
include 'config/database.php';

// 3. Inisialisasi variabel $error dengan string kosong untuk menampung pesan kesalahan jika login gagal.
$error = '';

// 4. Memeriksa apakah form login telah disubmit (apakah tombol bertipe name="login" sudah diklik).
if (isset($_POST['login'])) {
    
    // 5. Mengamankan input username dari risiko SQL Injection menggunakan mysqli_real_escape_string.
    $username = mysqli_real_escape_string($conn, $_POST['username']);
    
    // 6. Mengambil data password yang diinputkan oleh user melalui metode POST.
    $password = $_POST['password'];

    // 7. Membuat query SQL untuk mencari kecocokan username dan password di tabel 'users'.
    $query = "SELECT * FROM users WHERE name='$username' AND password='$password'";
    
    // 8. Menjalankan query ke database menggunakan fungsi mysqli_query.
    $result = mysqli_query($conn, $query);

    // 9. Memeriksa apakah jumlah baris data yang ditemukan lebih besar dari 0 (artinya akun terdaftar).
    if (mysqli_num_rows($result) > 0) {
        
        // [BARU] Mengambil data array pengguna dari database untuk mendapatkan kolom 'role'
        $row = mysqli_fetch_assoc($result);
        
        // 10. Membuat session baru bernama $_SESSION['admin'] untuk mengunci status login pengguna.
        $_SESSION['admin'] = $username;
        
        // [BARU] Menyimpan data role ke session untuk membedakan akses Admin Utama & Staff di sidebar/halaman
        $_SESSION['role'] = $row['role'];
        
        // 11. Mengarahkan (redirect) halaman secara otomatis ke dashboard.php jika login sukses.
        header("Location: dashboard.php");
        
        // 12. Menghentikan eksekusi script setelah proses redirect agar server tidak memproses kode di bawahnya.
        exit;
    } else {
        // 13. Jika data tidak cocok, variabel $error diisi dengan pesan peringatan teks.
        $error = "Username atau Password salah!";
    }
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Login - Warung Kelontong JWP</title>
    <link rel="stylesheet" href="assets/css/bootstrap.min.css">
</head>
<body class="bg-light d-flex align-items-center" style="height: 100vh;">
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-4">
            <div class="card shadow-sm border-0">
                <div class="card-body p-4">
                    <h3 class="card-title text-center mb-4 fw-bold text-dark">Login Admin</h3>
                    
                    <?php if($error): ?>
                        <div class="alert alert-danger py-2 small shadow-sm"><?= $error; ?></div>
                    <?php endif; ?>

                    <form action="" method="POST">
                        <div class="mb-3">
                            <label class="form-label small fw-bold text-secondary">Username</label>
                            <input type="text" name="username" class="form-control" placeholder="Masukkan username" required autocomplete="off">
                        </div>
                        <div class="mb-3">
                            <label class="form-label small fw-bold text-secondary">Password</label>
                            <input type="password" name="password" class="form-control" placeholder="Masukkan password" required>
                        </div>
                        <button type="submit" name="login" class="btn btn-primary w-100 fw-bold shadow-sm">Masuk</button>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
</body>
</html>