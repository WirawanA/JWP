<?php
// TAMBAHKAN BARIS INI: Mengaktifkan Output Buffering agar fungsi header() tidak bentrok dengan HTML
ob_start(); 

// 1. Memeriksa status sistem Session PHP.
if (session_status() == PHP_SESSION_NONE) {
    session_start();
}

// 2. KEAMANAN / SISTEM PROTEKSI HAK AKSES
if (!isset($_SESSION['admin'])) {
    header("Location: index.php");
    exit;
}

// 3. Menyisipkan file konfigurasi database
include __DIR__ . '/../config/database.php';

// 4. Mengambil nama file PHP yang sedang diakses saat ini
$current_page = basename($_SERVER['PHP_SELF']);
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/xlsx/0.18.5/xlsx.full.min.js"></script>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Warung Kelontong JWP</title>
    
    <link rel="stylesheet" href="<?= $base_url; ?>assets/css/bootstrap.min.css">
    
    <style>
        body { 
            overflow-x: hidden; 
            background-color: #f8f9fa; 
        }
        .sidebar {
            min-height: 100vh; 
            background-color: #212529; 
            color: #fff;
            position: fixed; 
            top: 0;
            left: 0;
            z-index: 100; 
        }
        .sidebar .nav-link {
            color: rgba(255,255,255,0.75); 
            padding: 12px 20px; 
            margin-bottom: 5px;
            border-radius: 5px; 
        }
        .sidebar .nav-link:hover {
            background-color: #343a40; 
            color: #ffc107; 
        }
        .sidebar .nav-link.active {
            background-color: #ffc107; 
            color: #212529; 
            font-weight: bold; 
        }
        .main-content { padding-top: 20px; } 
    </style>
</head>
<body>

<div class="container-fluid">
    <div class="row">
        
        <div class="col-md-3 col-lg-2 px-0 sidebar d-flex flex-column p-3">
            <div class="text-center my-3">
                <h5 class="fw-bold text-warning m-0">Warung Kelontong</h5>
                <small class="text-muted d-block mt-1">Halo, <?= $_SESSION['admin']; ?></small>
                <span class="badge <?= ($_SESSION['role'] == 'Admin Utama') ? 'bg-danger' : 'bg-info text-dark'; ?> mt-1">
                    <?= $_SESSION['role'] ?? 'Staff'; ?>
                </span>
            </div>
            <hr class="text-secondary"> 
            
            <ul class="nav nav-pills flex-column mb-auto">
                <li class="nav-item">
                    <a href="<?= $base_url; ?>dashboard.php" class="nav-link <?= ($current_page == 'dashboard.php') ? 'active' : ''; ?>">
                        📊 Dashboard
                    </a>
                </li>
                
                <li>
                    <a href="<?= $base_url; ?>master_data.php" class="nav-link <?= ($current_page == 'master_data.php') ? 'active' : ''; ?>">
                        📦 Master Data Barang
                    </a>
                </li>

                <li>
                    <a href="<?= $base_url; ?>persediaan.php" class="nav-link <?= ($current_page == 'persediaan.php') ? 'active' : ''; ?>">
                        🔄 Persediaan Barang
                    </a>
                </li>

                <li>
                    <a href="<?= $base_url; ?>kategori.php" class="nav-link <?= ($current_page == 'kategori.php') ? 'active' : ''; ?>">
                        🗂️ Kategori Barang
                    </a>
                </li>

                <?php if(isset($_SESSION['role']) && $_SESSION['role'] == 'Admin Utama'): ?>
                <li>
                    <a href="<?= $base_url; ?>pengguna.php" class="nav-link <?= ($current_page == 'pengguna.php') ? 'active' : ''; ?>">
                        👥 Manajemen Pengguna
                    </a>
                </li>
                <?php endif; ?>

                <li>
                    <a href="<?= $base_url; ?>laporan.php" class="nav-link <?= ($current_page == 'laporan.php') ? 'active' : ''; ?>">
                        📋 Laporan Mutasi
                    </a>
                </li>
                
                <li>
                    <a href="<?= $base_url; ?>ganti_password.php" class="nav-link <?= ($current_page == 'ganti_password.php') ? 'active' : ''; ?>">
                        🔑 Ganti Password
                    </a>
                </li>
            </ul>
            
            <hr class="text-secondary">
            
            <div class="d-grid">
                <a href="<?= $base_url; ?>logout.php" class="btn btn-sm btn-danger fw-bold" onclick="return confirm('Keluar dari aplikasi?')">🚪 Log Out</a>
            </div>
        </div>

        <div class="col-md-9 ms-sm-auto col-lg-10 px-md-4 main-content">