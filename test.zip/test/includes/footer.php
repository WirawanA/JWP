</div> 

</div> 

</div> 

<script src="<?= $base_url; ?>assets/js/bootstrap.bundle.min.js"></script>

</body>

</html>